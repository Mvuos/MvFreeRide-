class_name Vehicle
extends RigidBody3D
## Техника: RigidBody3D + подвеска на лучах (raycast). Три типа: велосипед, мотоцикл, квадроцикл.
## Колёса — не физические тела: каждый луч даёт пружину/демпфер и трение (круг трения).

const G := 9.81
const GEARS := [0.0, 13.5, 9.8, 7.4, 5.9, 4.8]
## Поверхность: [сцепление, сопротивление качению]
const SURF := {
    "asphalt": [1.15, 0.010], "concrete": [1.05, 0.008], "wood": [0.85, 0.012],
    "dirt": [0.90, 0.030], "grass": [0.65, 0.060],
}
const DEFS := {
    "enduro_dh": {"name": "Enduro DH (вело)", "kind": "bicycle", "model": "res://models/enduro_bicycle_dh.glb",
        "len": 1.75, "mass": 95.0, "dims": Vector3(0.6, 1.0, 1.75), "steer": 32.0, "drag": 0.35},
    "beta450": {"name": "Beta 450 RX (мото)", "kind": "motorcycle", "model": "res://models/beta_450_rx.glb",
        "len": 2.15, "mass": 205.0, "dims": Vector3(0.8, 1.2, 2.15), "steer": 28.0, "drag": 0.45},
    "santa_cruz": {"name": "Santa Cruz V10 (вело)", "kind": "bicycle", "model": "res://models/santa_cruz_v10.glb",
        "len": 1.85, "mass": 98.0, "dims": Vector3(0.6, 1.0, 1.85), "steer": 32.0, "drag": 0.35},
    "afterburner": {"name": "Afterburner DH (вело)", "kind": "bicycle", "model": "res://models/afterburner_dh.glb",
        "len": 1.8, "mass": 97.0, "dims": Vector3(0.6, 1.0, 1.8), "steer": 32.0, "drag": 0.35},
    "bmx": {"name": "BMX (вело)", "kind": "bicycle", "model": "res://models/bmx.glb",
        "len": 1.4, "mass": 80.0, "dims": Vector3(0.55, 0.9, 1.4), "steer": 40.0, "drag": 0.3,
        "wr": 0.25, "my": 0.24, "rest": 0.14, "travel": 0.08},
    "raptor": {"name": "Yamaha Raptor (квадро)", "kind": "quad", "model": "res://models/quad_yamaha_raptor_atv.glb",
        "len": 1.85, "mass": 290.0, "dims": Vector3(1.1, 1.0, 1.85), "steer": 32.0, "drag": 0.6},
    "atv_pure": {"name": "ATV (квадро)", "kind": "quad", "model": "res://models/atv_pure.glb",
        "len": 1.9, "mass": 300.0, "dims": Vector3(1.15, 1.0, 1.9), "steer": 32.0, "drag": 0.6},
}

class Wheel:
    var pos := Vector3.ZERO
    var radius := 0.35
    var rest := 0.2
    var travel := 0.18
    var k := 8000.0
    var c := 900.0
    var steer := false
    var drive := false
    var brake := true
    var comp := 0.0
    var prev := 0.0
    var grounded := false
    var spin := 0.0
    var steer_angle := 0.0
    var load_n := 0.0
    var drive_force := 0.0

var id := ""
var kind := "bicycle"
var display_name := ""
var wheels: Array[Wheel] = []
## Ввод: throttle 0..1, brake 0..1, steer -1..1 (вправо +), lean_fb -1..1 (вперёд +), jump bool
var inp := {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "lean_fb": 0.0, "jump": false}
var occupied := false
var grounded_count := 0
var ground_n := Vector3.UP
var air_time := 0.0
var drag := 0.35
var brake_force := 650.0
var max_steer_deg := 30.0
var preload_v := 0.0
var jump_charge := 0.0
var prev_jump := false
var last_steer := 0.0
var rpm := 1500.0
var gear := 1
var reversing := false
var seat_feet := Vector3(0, -0.1, 0.15)
var holder: Node3D
var flipped := false
var spec := {}
var _space: PhysicsDirectSpaceState3D

func setup(def_id: String, flip: bool) -> void:
    id = def_id
    var d: Dictionary = DEFS[def_id]
    spec = d
    kind = d["kind"]
    display_name = d["name"]
    mass = d["mass"]
    drag = d["drag"]
    max_steer_deg = d["steer"]
    var dims: Vector3 = d["dims"]
    var length: float = d["len"]
    collision_layer = 2
    collision_mask = 3
    can_sleep = false
    continuous_cd = true
    angular_damp = 0.4
    linear_damp = 0.0
    center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
    center_of_mass = Vector3.ZERO
    inertia = Vector3(mass / 12.0 * (dims.y * dims.y + dims.z * dims.z),
        mass / 12.0 * (dims.x * dims.x + dims.z * dims.z),
        mass / 12.0 * (dims.x * dims.x + dims.y * dims.y))
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(dims.x * 0.8, 0.5, length * 0.7)
    cs.shape = bs
    cs.position = Vector3(0, 0.6, 0)
    add_child(cs)
    _make_wheels(length)
    var w0: Wheel = wheels[0]
    var c0: float = mass * G / wheels.size() / w0.k
    var ground_y: float = w0.pos.y - (w0.rest + w0.travel - c0) - w0.radius
    holder = Node3D.new()
    holder.position = Vector3(0, ground_y, 0)
    add_child(holder)
    var vis := ModelUtil.make_vehicle_visual(d["model"], length)
    if vis == null:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(dims.x * 0.6, 0.6, length)
        mi.mesh = bm
        mi.position = Vector3(0, 0.5, 0)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.85, 0.3, 0.2)
        mi.material_override = mat
        holder.add_child(mi)
    else:
        holder.add_child(vis)
    apply_flip(flip)

func apply_flip(f: bool) -> void:
    flipped = f
    if holder != null:
        holder.rotation.y = PI if f else 0.0

func _wheel(p: Vector3, r: float, rest: float, travel: float, share: float, sag: float) -> Wheel:
    var w := Wheel.new()
    w.pos = p
    w.radius = r
    w.rest = rest
    w.travel = travel
    w.k = mass * G * share / sag
    w.c = w.k * 0.13
    return w

func _make_wheels(length: float) -> void:
    match kind:
        "bicycle":
            var l := length * 0.36
            var wr: float = spec.get("wr", 0.35)
            var my: float = spec.get("my", 0.30)
            var rs: float = spec.get("rest", 0.20)
            var tv: float = spec.get("travel", 0.18)
            var f := _wheel(Vector3(0, my, -l), wr, rs, tv, 0.5, 0.06)
            f.steer = true
            var r := _wheel(Vector3(0, my, l), wr, rs, tv, 0.5, 0.06)
            r.drive = true
            wheels.append(f)
            wheels.append(r)
            brake_force = 650.0
            seat_feet = Vector3(0, -0.1, 0.15)
        "motorcycle":
            var l := length * 0.36
            var f := _wheel(Vector3(0, 0.45, -l), 0.40, 0.30, 0.27, 0.5, 0.08)
            f.steer = true
            var r := _wheel(Vector3(0, 0.45, l), 0.38, 0.30, 0.27, 0.5, 0.08)
            r.drive = true
            wheels.append(f)
            wheels.append(r)
            brake_force = 2600.0
            seat_feet = Vector3(0, -0.1, 0.2)
        _:
            var l := length * 0.34
            var hw := 0.45
            var fl := _wheel(Vector3(-hw, 0.25, -l), 0.28, 0.22, 0.18, 0.25, 0.07)
            var fr := _wheel(Vector3(hw, 0.25, -l), 0.28, 0.22, 0.18, 0.25, 0.07)
            fl.steer = true
            fr.steer = true
            var rl := _wheel(Vector3(-hw, 0.25, l), 0.28, 0.22, 0.18, 0.25, 0.07)
            var rr := _wheel(Vector3(hw, 0.25, l), 0.28, 0.22, 0.18, 0.25, 0.07)
            rl.drive = true
            rr.drive = true
            wheels.append(fl)
            wheels.append(fr)
            wheels.append(rl)
            wheels.append(rr)
            brake_force = 1400.0
            seat_feet = Vector3(0, -0.1, 0.15)

func teleport(xf: Transform3D) -> void:
    var rid := get_rid()
    PhysicsServer3D.body_set_state(rid, PhysicsServer3D.BODY_STATE_TRANSFORM, xf)
    PhysicsServer3D.body_set_state(rid, PhysicsServer3D.BODY_STATE_LINEAR_VELOCITY, Vector3.ZERO)
    PhysicsServer3D.body_set_state(rid, PhysicsServer3D.BODY_STATE_ANGULAR_VELOCITY, Vector3.ZERO)

func _physics_process(dt: float) -> void:
    if freeze:
        return
    if not occupied:
        inp = {"throttle": 0.0, "brake": 0.5, "steer": 0.0, "lean_fb": 0.0, "jump": false}
    _space = get_world_3d().direct_space_state
    _control(dt)
    _wheels(dt)
    var sp := linear_velocity.length()
    if sp > 0.1:
        apply_central_force(-linear_velocity * drag * sp)

# ---------------------------------------------------------------- управление
func _engine_torque(r: float) -> float:
    var x: float = clampf((r - 2000.0) / 8000.0, 0.0, 1.0)
    return 43.0 * (0.55 + 2.4 * x * (1.0 - x)) * (0.0 if r > 10500.0 else 1.0)

func _control(dt: float) -> void:
    var bas := global_transform.basis
    var fwd := -bas.z
    var vf: float = linear_velocity.dot(fwd)
    var v: float = absf(vf)
    var steer_in: float = inp["steer"]
    var thr: float = inp["throttle"]
    var brk: float = inp["brake"]
    var jump_in: bool = inp["jump"]
    var lean_fb: float = inp["lean_fb"]
    for w in wheels:
        w.drive_force = 0.0
    reversing = brk > 0.2 and vf < 0.4 and thr < 0.1 and occupied
    var maxs := deg_to_rad(max_steer_deg)
    match kind:
        "bicycle":
            last_steer = lerpf(last_steer, steer_in * maxs / (1.0 + v * 0.35), 1.0 - exp(-10.0 * dt))
            wheels[0].steer_angle = last_steer
            var thrust: float = minf(220.0, 260.0 * thr / maxf(v, 1.2))
            if v > 12.0:
                thrust = 0.0
            if reversing:
                thrust = -90.0
            if wheels[1].grounded:
                wheels[1].drive_force = thrust
            _hop(jump_in, dt, 2.0, 3.2, 2.2)
            _stabilize(2200.0, 260.0, deg_to_rad(40.0))
            if grounded_count > 0:
                apply_torque(-bas.x * lean_fb * 120.0)
            _air(dt, 140.0)
        "motorcycle":
            last_steer = lerpf(last_steer, steer_in * maxs / (1.0 + v * 0.12), 1.0 - exp(-12.0 * dt))
            wheels[0].steer_angle = last_steer
            var rr: float = wheels[1].radius
            var wheel_rpm: float = v / rr * 60.0 / TAU
            rpm = maxf(1500.0, wheel_rpm * GEARS[gear])
            if rpm > 9500.0 and gear < 5:
                gear += 1
            elif rpm < 4200.0 and gear > 1:
                gear -= 1
            var f: float = _engine_torque(rpm) * thr * GEARS[gear] * 0.9 / rr
            if reversing:
                f = -500.0
            if wheels[1].grounded:
                wheels[1].drive_force = f
            _hop(jump_in, dt, 1.5, 3.0, 2.5)
            _stabilize(4200.0, 520.0, deg_to_rad(50.0))
            var wl: float = lean_fb * 380.0
            if lean_fb < -0.3:
                wl -= thr * 500.0
            if grounded_count > 0:
                apply_torque(-bas.x * wl)
            _air(dt, 320.0)
        _:
            var steer := lerpf(last_steer, steer_in, 1.0 - exp(-10.0 * dt))
            last_steer = steer
            var a: float = steer * maxs / (1.0 + v * 0.08)
            wheels[0].steer_angle = a * (0.85 if steer > 0.0 else 1.15)
            wheels[1].steer_angle = a * (1.15 if steer > 0.0 else 0.85)
            var f: float = minf(2400.0, 15000.0 * thr / maxf(v, 3.0))
            if reversing:
                f = -700.0
            for i in [2, 3]:
                if wheels[i].grounded:
                    wheels[i].drive_force = f * 0.5
            _hop(jump_in, dt, 1.2, 2.4, 2.0)
            if grounded_count > 0:
                apply_torque(-bas.x * lean_fb * 700.0)
            _air(dt, 450.0)

func _hop(jump_in: bool, dt: float, base: float, extra: float, rate: float) -> void:
    var released: bool = prev_jump and not jump_in
    if released and grounded_count > 0:
        apply_central_impulse(ground_n * mass * (base + extra * jump_charge))
        jump_charge = 0.0
    elif jump_in:
        jump_charge = minf(1.0, jump_charge + dt * rate)
    else:
        jump_charge = lerpf(jump_charge, 0.0, 1.0 - exp(-12.0 * dt))
    preload_v = jump_charge
    prev_jump = jump_in

## PD-регулятор крена двухколёсника: держит вертикаль, наклоняет в поворот.
func _stabilize(kp: float, kd: float, max_lean: float) -> void:
    if grounded_count == 0:
        return
    var bas := global_transform.basis
    var fwd := -bas.z
    var up := bas.y
    var yaw_rate: float = angular_velocity.dot(ground_n)
    var vf: float = linear_velocity.dot(fwd)
    var want: float = clampf(atan2(-vf * yaw_rate, G), -max_lean, max_lean)
    var up_t: Vector3 = (ground_n - fwd * ground_n.dot(fwd)).normalized()
    var lean: float = atan2(up_t.cross(up).dot(fwd), up_t.dot(up))
    var tau: float = kp * (want - lean) - kd * angular_velocity.dot(fwd)
    apply_torque(fwd * tau * (1.0 if grounded_count >= 2 else 0.5))

func _air(dt: float, auth: float) -> void:
    if grounded_count > 0:
        return
    var bas := global_transform.basis
    var fb: float = inp["lean_fb"]
    apply_torque(-bas.x * fb * auth)
    if air_time > 0.25 and linear_velocity.y < 1.0 and absf(fb) < 0.05:
        var probe := global_position + linear_velocity * 0.25
        var h := _space.intersect_ray(PhysicsRayQueryParameters3D.create(probe, probe + Vector3.DOWN * 12.0, 1))
        if not h.is_empty():
            var n: Vector3 = h["normal"]
            var axis: Vector3 = bas.y.cross(n)
            apply_torque(axis * auth * 1.2 - angular_velocity * auth * 0.15)

# ---------------------------------------------------------------- колёса
func _wheels(dt: float) -> void:
    var xf := global_transform
    var bas := xf.basis
    var up := bas.y
    var count := 0
    var gn := Vector3.ZERO
    for w in wheels:
        var max_len: float = w.rest + w.travel
        var mount: Vector3 = xf * w.pos
        var q := PhysicsRayQueryParameters3D.create(mount, mount - up * (max_len + w.radius), 1)
        var hit := _space.intersect_ray(q)
        w.prev = w.comp
        if hit.is_empty():
            w.grounded = false
            w.comp = 0.0
            w.load_n = 0.0
            continue
        var hp: Vector3 = hit["position"]
        var n: Vector3 = hit["normal"]
        var dist: float = mount.distance_to(hp)
        var sus_len: float = clampf(dist - w.radius, 0.0, max_len)
        w.comp = max_len - sus_len
        var comp_vel: float = clampf((w.comp - w.prev) / dt, -6.0, 6.0)
        var load_n: float = maxf(0.0, w.k * w.comp + w.c * comp_vel)
        load_n *= 1.0 + preload_v * 0.4
        w.grounded = true
        w.load_n = load_n
        count += 1
        gn += n
        var r: Vector3 = hp - global_position
        apply_force(n * load_n, r)

        var surf := "grass"
        var col = hit["collider"]
        if col != null and col.has_meta("surface"):
            surf = String(col.get_meta("surface"))
        if surf == "terrain":
            surf = "grass" if hp.z > -40.0 else "dirt"
        var sp: Array = SURF.get(surf, SURF["dirt"])
        var grip: float = sp[0]
        var roll: float = sp[1]

        var fwd: Vector3 = (-bas.z).rotated(up, -w.steer_angle)
        fwd = (fwd - n * fwd.dot(n)).normalized()
        var side: Vector3 = fwd.cross(n).normalized()
        var vel_at: Vector3 = linear_velocity + angular_velocity.cross(r)
        var v_long: float = vel_at.dot(fwd)
        var v_lat: float = vel_at.dot(side)
        var max_f: float = grip * load_n
        var f_lat: float = clampf(-v_lat * load_n, -max_f, max_f)
        var f_long: float = w.drive_force
        var brk: float = float(inp["brake"])
        if w.brake and brk > 0.0 and not reversing:
            f_long -= signf(v_long) * minf(absf(v_long) * 400.0, brk * brake_force)
        f_long -= clampf(v_long * 50.0, -1.0, 1.0) * roll * load_n
        var lim: float = sqrt(maxf(0.0, max_f * max_f - f_lat * f_lat))
        f_long = clampf(f_long, -lim, lim)
        apply_force(fwd * f_long + side * f_lat, r)
        w.spin += v_long / w.radius * dt
    grounded_count = count
    ground_n = gn.normalized() if count > 0 else Vector3.UP
    air_time = air_time + dt if count == 0 else 0.0
