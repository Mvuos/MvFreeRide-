class_name Player
extends CharacterBody3D
## Пешеход: капсула + простая фигурка, шлем из enduro_helmet.glb. За рулём «приклеен» к сиденью.

var yaw := 0.0
var visual: Node3D
var mounted := false

func _ready() -> void:
    collision_layer = 4
    collision_mask = 1
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.3
    cap.height = 1.7
    cs.shape = cap
    cs.position = Vector3(0, 0.85, 0)
    add_child(cs)
    visual = Node3D.new()
    add_child(visual)
    var body := MeshInstance3D.new()
    var cm := CapsuleMesh.new()
    cm.radius = 0.26
    cm.height = 1.4
    body.mesh = cm
    body.position = Vector3(0, 0.72, 0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.95, 0.45, 0.1)
    body.material_override = mat
    visual.add_child(body)
    var helmet := ModelUtil.make_prop("res://models/enduro_helmet.glb", 0.36)
    if helmet != null:
        helmet.position = Vector3(0, 1.38, 0)
        visual.add_child(helmet)
    else:
        var hs := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 0.17
        sm.height = 0.34
        hs.mesh = sm
        hs.position = Vector3(0, 1.5, 0)
        visual.add_child(hs)

func walk(dt: float, move: Vector2, cam_yaw: float, run: bool, jump: bool) -> void:
    var fwd := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw))
    var right := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
    var wish := fwd * move.y + right * move.x
    if wish.length() > 1.0:
        wish = wish.normalized()
    var sp := 6.0 if run else 3.2
    var k := 1.0 - exp(-10.0 * dt)
    velocity.x = lerpf(velocity.x, wish.x * sp, k)
    velocity.z = lerpf(velocity.z, wish.z * sp, k)
    velocity.y -= 22.0 * dt
    if jump and is_on_floor():
        velocity.y = 6.0
    move_and_slide()
    if wish.length() > 0.1:
        yaw = lerp_angle(yaw, atan2(-wish.x, -wish.z), 1.0 - exp(-12.0 * dt))
        rotation.y = yaw

func mount() -> void:
    mounted = true
    collision_layer = 0
    collision_mask = 0
    velocity = Vector3.ZERO
    visual.scale = Vector3(1, 0.8, 1)

func follow(v: Vehicle) -> void:
    global_transform = v.global_transform * Transform3D(Basis.IDENTITY, v.seat_feet)

func unmount(pos: Vector3, vel: Vector3) -> void:
    mounted = false
    collision_layer = 4
    collision_mask = 1
    visual.scale = Vector3.ONE
    global_position = pos
    velocity = vel
