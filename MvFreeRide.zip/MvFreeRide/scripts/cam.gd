class_name FollowCam
extends Camera3D
## Камера погони: сглаживание, дистанция и FOV зависят от скорости и полёта, не проходит сквозь рельеф.

var yaw := 0.0
var pitch := 0.2
var dist := 4.0
var fov_cur := 65.0
var sm := Vector3.ZERO
var idle := 0.0
var air_blend := 0.0

func snap(t: Vector3, y: float) -> void:
    sm = t
    yaw = y
    dist = 3.6
    fov_cur = 65.0
    fov = fov_cur
    near = 0.15
    far = 1800.0

## follow=true — техника (авто-доворот за вектором скорости), false — пешком.
func step(dt: float, target: Vector3, vel: Vector3, airborne: bool, air_time: float, look: Vector2, follow: bool) -> void:
    var speed := vel.length()
    var s := clampf(speed / 25.0, 0.0, 1.0)
    var want := target + vel * 0.12
    sm = sm.lerp(want, 1.0 - exp(-7.0 * dt))
    air_blend = lerpf(air_blend, 1.0 if airborne else 0.0, 1.0 - exp(-4.0 * dt))
    sm.y = lerpf(sm.y, want.y, 1.0 - exp(-7.0 * (1.0 - 0.6 * air_blend) * dt))

    if look.length() > 0.001:
        idle = 0.0
    else:
        idle += dt
    yaw -= look.x * 0.006
    pitch = clampf(pitch + look.y * 0.005, -0.1, 1.2)
    if follow and speed > 2.0 and idle > 1.0:
        var vy := atan2(-vel.x, -vel.z)
        var k := 3.5 * clampf((speed - 2.0) / 6.0, 0.0, 1.0)
        yaw += angle_difference(yaw, vy) * (1.0 - exp(-k * dt))

    var want_d := 3.8
    var want_f := 65.0
    if follow:
        var boost := 0.0
        if airborne:
            boost = clampf(air_time / 1.2, 0.0, 1.0) * 2.0
        want_d = lerpf(3.2, 7.5, s) + boost
        want_f = lerpf(65.0, 88.0, s * s) + (4.0 if airborne else 0.0)
    dist = lerpf(dist, want_d, 1.0 - exp(-2.5 * dt))
    fov_cur = lerpf(fov_cur, want_f, 1.0 - exp(-3.0 * dt))
    fov = fov_cur

    var pbias := 0.0
    if airborne:
        pbias = clampf(-vel.y * 0.02, -0.15, 0.35)
    elif speed > 1.0:
        pbias = clampf(-vel.y / maxf(speed, 1.0) * 0.4, -0.1, 0.25)
    var p := clampf(pitch + pbias, -0.15, 1.3)
    var dir := Vector3(sin(yaw) * cos(p), sin(p), cos(yaw) * cos(p))
    var pivot := sm + Vector3(0, 1.4, 0)
    var d := dist
    var space := get_world_3d().direct_space_state
    var h := space.intersect_ray(PhysicsRayQueryParameters3D.create(pivot, pivot + dir * (d + 0.3), 1))
    if not h.is_empty():
        var hp: Vector3 = h["position"]
        d = maxf(0.8, pivot.distance_to(hp) - 0.3)
    var pos := pivot + dir * d
    var h2 := space.intersect_ray(PhysicsRayQueryParameters3D.create(pos + Vector3.UP * 2.0, pos + Vector3.DOWN * 4.0, 1))
    if not h2.is_empty():
        var gp: Vector3 = h2["position"]
        pos.y = maxf(pos.y, gp.y + 0.4)
    look_at_from_position(pos, pivot, Vector3.UP)
