class_name TouchUI
extends Control
## Мультитач-управление, рисуется кодом: плавающий стик слева, кнопки справа, свайп справа — камера.
## Работает и с мышью (эмуляция касаний включена в project.godot).

const BTN := [
    {"id": "gas", "x": 0.90, "y": 0.74, "r": 0.105, "t": "ГАЗ", "tap": false},
    {"id": "brake", "x": 0.75, "y": 0.86, "r": 0.075, "t": "ТОРМ", "tap": false},
    {"id": "jump", "x": 0.74, "y": 0.62, "r": 0.075, "t": "ПРЫЖОК", "tap": false},
    {"id": "use", "x": 0.90, "y": 0.48, "r": 0.07, "t": "", "tap": true},
    {"id": "run", "x": 0.60, "y": 0.88, "r": 0.055, "t": "БЕГ", "tap": false},
    {"id": "reset", "x": 0.95, "y": 0.09, "r": 0.05, "t": "СБРОС", "tap": true},
    {"id": "tp", "x": 0.86, "y": 0.09, "r": 0.05, "t": "ТП", "tap": true},
    {"id": "flip", "x": 0.77, "y": 0.09, "r": 0.05, "t": "РАЗВ.", "tap": true},
]

var held := {}
var taps := {}
var stick := Vector2.ZERO
var look := Vector2.ZERO
var info: Array = []
var use_label := "СЕСТЬ"
var _touch := {}
var _origin := Vector2.ZERO
var _active := false

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func take(name_: String) -> bool:
    if taps.get(name_, false):
        taps[name_] = false
        return true
    return false

func is_held(name_: String) -> bool:
    return held.get(name_, false)

func take_look() -> Vector2:
    var l := look
    look = Vector2.ZERO
    return l

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _press(event.index, event.position)
        else:
            _release(event.index)
    elif event is InputEventScreenDrag:
        _drag(event.index, event.position, event.relative)

func _press(idx: int, pos: Vector2) -> void:
    var m := minf(size.x, size.y)
    for b in BTN:
        var c := Vector2(size.x * b["x"], size.y * b["y"])
        if pos.distance_to(c) <= m * float(b["r"]) * 1.3:
            _touch[idx] = b["id"]
            held[b["id"]] = true
            if b["tap"]:
                taps[b["id"]] = true
            return
    if pos.x < size.x * 0.45 and pos.y > size.y * 0.25:
        _touch[idx] = "stick"
        _active = true
        _origin = pos
        stick = Vector2.ZERO
    else:
        _touch[idx] = "cam"

func _release(idx: int) -> void:
    var role = _touch.get(idx, "")
    _touch.erase(idx)
    if role == "stick":
        _active = false
        stick = Vector2.ZERO
    elif role != "" and role != "cam":
        held[role] = false

func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    var role = _touch.get(idx, "")
    if role == "stick":
        var R := minf(size.x, size.y) * 0.16
        var v := (pos - _origin).limit_length(R)
        stick = Vector2(v.x / R, -v.y / R)
    elif role == "cam":
        look += rel

func _process(_dt: float) -> void:
    queue_redraw()

func _draw() -> void:
    var m := minf(size.x, size.y)
    var font := ThemeDB.fallback_font
    for b in BTN:
        var c := Vector2(size.x * b["x"], size.y * b["y"])
        var rad: float = m * float(b["r"])
        var on: bool = held.get(b["id"], false)
        draw_circle(c, rad, Color(1, 1, 1, 0.32 if on else 0.14))
        draw_arc(c, rad, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
        var label: String = b["t"]
        if b["id"] == "use":
            label = use_label
        draw_string(font, c + Vector2(-rad, 6), label, HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 18, Color(1, 1, 1, 0.9))
    var R := m * 0.16
    var base := _origin if _active else Vector2(size.x * 0.14, size.y * 0.74)
    draw_circle(base, R, Color(1, 1, 1, 0.10))
    draw_arc(base, R, 0.0, TAU, 40, Color(1, 1, 1, 0.4), 2.0)
    var knob := base + Vector2(stick.x, -stick.y) * R
    draw_circle(knob, R * 0.38, Color(1, 1, 1, 0.35))
    var y := 30.0
    for line in info:
        draw_string(font, Vector2(24, y), String(line), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1, 0.95))
        y += 28.0
