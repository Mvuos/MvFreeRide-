extends Node3D
## Точка входа: строит мир, спавнит технику и игрока, связывает ввод, камеру и HUD.

const FLIPS_PATH := "user://flips.cfg"
const TPS := [
    ["Лес: верх трассы", Vector3(0, 0, -640)],
    ["Лес: дёрт-джамп", Vector3(-152, 0, -405)],
    ["Город", Vector3(0, 0, 282)],
    ["Скейт-парк", Vector3(118, 0, 312)],
    ["Indoor-парк", Vector3(-340, 0, 280)],
]

var world: GameWorld
var player: Player
var cam: FollowCam
var ui: TouchUI
var vehicles: Array[Vehicle] = []
var current: Vehicle = null
var tp_i := 0
var ready_flag := false
var loading: Label
var flips := ConfigFile.new()
var cull_t := 0.0

func _ready() -> void:
    flips.load(FLIPS_PATH)
    var layer := CanvasLayer.new()
    add_child(layer)
    ui = TouchUI.new()
    layer.add_child(ui)
    ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    loading = Label.new()
    loading.text = "Загрузка мира..."
    loading.position = Vector2(40, 40)
    loading.add_theme_font_size_override("font_size", 36)
    layer.add_child(loading)
    await get_tree().process_frame
    await get_tree().process_frame

    _setup_env()
    world = GameWorld.new()
    add_child(world)
    world.build()

    player = Player.new()
    add_child(player)
    cam = FollowCam.new()
    add_child(cam)
    cam.current = true

    _spawn("enduro_dh", Vector3(2.5, 0, -642), PI)
    _spawn("enduro_dh", Vector3(-150, 0, -402), PI)
    _spawn("beta450", Vector3(14, 0, 285), 0.0)
    _spawn("raptor", Vector3(-14, 0, 285), 0.0)
    _spawn("enduro_dh", Vector3(0, 0, 292), 0.0)
    _spawn("santa_cruz", Vector3(28, 0, 292), 0.0)
    _spawn("afterburner", Vector3(-28, 0, 292), 0.0)
    _spawn("atv_pure", Vector3(42, 0, 285), 0.0)
    _spawn("bmx", Vector3(118, 0, 322), 0.0)
    _spawn("afterburner", Vector3(6, 0, -640), PI)
    _spawn("santa_cruz", Vector3(-146, 0, -400), PI)
    _spawn("bmx", Vector3(-338, 0, 275), 0.0)

    _place_player(TPS[0][1] as Vector3)
    cam.snap(player.global_position, 0.0)
    loading.queue_free()
    ready_flag = true

func _setup_env() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    sky.sky_material = ProceduralSkyMaterial.new()
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.fog_enabled = true
    env.fog_light_color = Color(0.72, 0.8, 0.9)
    env.fog_density = 0.0008
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -30, 0)
    sun.light_energy = 1.1
    add_child(sun)

func _spawn(id: String, p: Vector3, yaw: float) -> Vehicle:
    var v := Vehicle.new()
    v.position = Vector3(p.x, world.height_at(p.x, p.z) + 1.0, p.z)
    v.rotation.y = yaw
    add_child(v)
    v.setup(id, bool(flips.get_value("flip", id, false)))
    vehicles.append(v)
    return v

func _place_player(p: Vector3) -> void:
    player.global_position = Vector3(p.x, world.height_at(p.x, p.z) + 0.3, p.z)
    player.velocity = Vector3.ZERO

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_E: ui.taps["use"] = true
            KEY_R: ui.taps["reset"] = true
            KEY_T: ui.taps["tp"] = true
            KEY_F: ui.taps["flip"] = true

func _kb(a: int, b: int) -> float:
    return float(Input.is_key_pressed(a)) - float(Input.is_key_pressed(b))

func _nearest() -> Vehicle:
    var best: Vehicle = null
    var bd := 3.5
    for v in vehicles:
        var d := v.global_position.distance_to(player.global_position)
        if d < bd:
            bd = d
            best = v
    return best

func _enter(v: Vehicle) -> void:
    current = v
    v.occupied = true
    player.mount()

func _exit_vehicle() -> void:
    var v := current
    var p := v.global_position - v.global_transform.basis.x * 1.2
    var hit := get_world_3d().direct_space_state.intersect_ray(
        PhysicsRayQueryParameters3D.create(p + Vector3.UP * 3.0, p + Vector3.DOWN * 8.0, 1))
    if hit.is_empty():
        p = v.global_position + Vector3.UP * 1.5
    else:
        var hp: Vector3 = hit["position"]
        p = hp + Vector3(0, 0.1, 0)
    v.occupied = false
    current = null
    player.unmount(p, v.linear_velocity * 0.4)

func _teleport(p: Vector3) -> void:
    var y := world.height_at(p.x, p.z)
    if current != null:
        current.teleport(Transform3D(Basis(Vector3.UP, PI if p.z < -50.0 else 0.0), Vector3(p.x, y + 1.2, p.z)))
    else:
        _place_player(p)
    cam.snap(Vector3(p.x, y, p.z), 0.0)

func _process(dt: float) -> void:
    if not ready_flag:
        return
    var move := Vector2(clampf(ui.stick.x + _kb(KEY_D, KEY_A), -1, 1), clampf(ui.stick.y + _kb(KEY_W, KEY_S), -1, 1))
    var look := ui.take_look()

    if ui.take("use"):
        if current != null:
            _exit_vehicle()
        else:
            var n := _nearest()
            if n != null:
                _enter(n)
    if ui.take("reset") and current != null:
        # Поставить технику ровно на колёса там же, сохранив курс
        var fwd := -current.global_transform.basis.z
        var yaw := atan2(-fwd.x, -fwd.z)
        current.teleport(Transform3D(Basis(Vector3.UP, yaw), current.global_position + Vector3.UP * 1.5))
    if ui.take("tp"):
        tp_i = (tp_i + 1) % TPS.size()
        _teleport(TPS[tp_i][1] as Vector3)
    if ui.take("flip") and current != null:
        var f := not current.flipped
        flips.set_value("flip", current.id, f)
        flips.save(FLIPS_PATH)
        for v in vehicles:
            if v.id == current.id:
                v.apply_flip(f)

    var tgt: Vector3
    var vel: Vector3
    var air := false
    var air_t := 0.0
    if current != null:
        var dead := 0.35
        var lean := 0.0 if absf(ui.stick.y) < dead else ui.stick.y
        lean += _kb(KEY_UP, KEY_DOWN)
        current.inp = {
            "throttle": 1.0 if (ui.is_held("gas") or Input.is_key_pressed(KEY_W)) else 0.0,
            "brake": 1.0 if (ui.is_held("brake") or Input.is_key_pressed(KEY_S)) else 0.0,
            "steer": move.x,
            "lean_fb": clampf(lean, -1.0, 1.0),
            "jump": ui.is_held("jump") or Input.is_key_pressed(KEY_SPACE),
        }
        player.follow(current)
        tgt = current.global_position
        vel = current.linear_velocity
        air = current.grounded_count == 0 and current.air_time > 0.05
        air_t = current.air_time
        ui.use_label = "ВЫЙТИ"
    else:
        player.walk(dt, move, cam.yaw, ui.is_held("run") or Input.is_key_pressed(KEY_SHIFT),
            ui.is_held("jump") or Input.is_key_pressed(KEY_SPACE))
        tgt = player.global_position
        vel = player.velocity
        ui.use_label = "СЕСТЬ"

    cam.step(dt, tgt, vel, air, air_t, look, current != null)

    # Оптимизация: далёкую технику замораживаем и прячем (физика и отрисовка только рядом)
    cull_t -= dt
    if cull_t <= 0.0:
        cull_t = 0.5
        for v in vehicles:
            var dd := v.global_position.distance_to(tgt)
            v.freeze = (dd > 160.0) and not v.occupied
            v.visible = dd < 300.0

    if not world.in_bounds(tgt):
        tp_i = 2
        _teleport(TPS[2][1] as Vector3)

    var lines: Array = []
    if current != null:
        lines.append("%s  %d км/ч" % [current.display_name, int(vel.length() * 3.6)])
        if current.kind == "motorcycle":
            lines.append("передача %d" % current.gear)
    else:
        var n2 := _nearest()
        lines.append("Пешком" + ("  —  рядом: " + n2.display_name + "  (СЕСТЬ)" if n2 != null else ""))
    lines.append("ТП: " + String(TPS[tp_i][0]) + "   FPS %d" % Engine.get_frames_per_second())
    ui.info = lines
