class_name GameWorld
extends Node3D
## Открытый мир: рельеф (город — плоский, лес поднимается к -Z), дороги, здания, скейт-парк,
## лесные трассы с кикерами/тейблтопами/роллерами/дропами, деревья из forest.glb.

const X0 := -480.0
const Z0 := -780.0
const CELL := 7.0
const NX := 137
const NZ := 190
const SKATE := Vector3(140.0, 0.0, 330.0)
const INDOOR := Vector3(-340.0, 0.0, 330.0)

## Трассы сверху вниз (к городу). at — доля длины трассы.
const TRAILS := [
    {"w": 2.8, "pts": [[-20, -700], [30, -600], [-10, -480], [40, -360], [0, -240], [-30, -120], [0, -40]],
     "feats": [
        {"t": "kicker", "at": 0.10, "L": 7.0, "H": 1.8},
        {"t": "table", "at": 0.25, "up": 5.0, "top": 6.0, "down": 7.0, "H": 1.6},
        {"t": "roller", "at": 0.38, "L": 14.0, "H": 0.7, "n": 4},
        {"t": "drop", "at": 0.55, "ramp": 5.0, "deck": 3.0, "H": 3.0},
        {"t": "kicker", "at": 0.72, "L": 8.0, "H": 2.2},
        {"t": "table", "at": 0.88, "up": 6.0, "top": 7.0, "down": 8.0, "H": 2.0}]},
    {"w": 3.0, "pts": [[-160, -420], [-150, -330], [-155, -240], [-150, -150]],
     "feats": [
        {"t": "kicker", "at": 0.15, "L": 5.0, "H": 1.3},
        {"t": "kicker", "at": 0.35, "L": 5.0, "H": 1.5},
        {"t": "kicker", "at": 0.55, "L": 5.0, "H": 1.7},
        {"t": "kicker", "at": 0.75, "L": 6.0, "H": 2.0}]},
]
## Дороги города: полилинии (x, z)
const ROADS := [
    [[-440, 250], [0, 250], [440, 250]],
    [[-440, 400], [0, 400], [440, 400]],
    [[0, 130], [0, 250], [0, 400], [0, 540]],
    [[-220, 130], [-220, 400], [-220, 540]],
    [[300, 130], [300, 400], [300, 540]],
]

var hts := PackedFloat32Array()
var trail_lines: Array = []

# ---------------------------------------------------------------- рельеф
func raw_height(x: float, z: float) -> float:
    var hills := 9.0 * (sin(x * 0.011 + 1.3) * cos(z * 0.013) + 0.5 * sin(x * 0.027 - z * 0.021 + 2.0) + 0.25 * sin(z * 0.05 + x * 0.04))
    var slope := clampf(-z / 900.0, 0.0, 1.0)
    var forest := slope * (60.0 + hills * 1.5) + hills * slope * 0.8
    var blend := smoothstep(-60.0, 80.0, z)
    return lerpf(forest, 0.0, blend)

## Высота ровно по тем же треугольникам, что и меш рельефа.
func height_at(x: float, z: float) -> float:
    var fx := clampf((x - X0) / CELL, 0.0, NX - 0.001)
    var fz := clampf((z - Z0) / CELL, 0.0, NZ - 0.001)
    var ix := int(fx)
    var iz := int(fz)
    var u := fx - ix
    var v := fz - iz
    var s := NX + 1
    var ha := hts[iz * s + ix]
    var hb := hts[iz * s + ix + 1]
    var hc := hts[(iz + 1) * s + ix]
    var hd := hts[(iz + 1) * s + ix + 1]
    if u + v <= 1.0:
        return ha + u * (hb - ha) + v * (hc - ha)
    return hd + (1.0 - u) * (hc - hd) + (1.0 - v) * (hb - hd)

func in_bounds(p: Vector3) -> bool:
    return p.x > X0 + 10.0 and p.x < X0 + NX * CELL - 10.0 and p.z > Z0 + 10.0 and p.z < Z0 + NZ * CELL - 10.0 and p.y > -40.0

func _build_terrain() -> void:
    var s := NX + 1
    hts.resize(s * (NZ + 1))
    var verts := PackedVector3Array()
    verts.resize(s * (NZ + 1))
    var cols := PackedColorArray()
    cols.resize(s * (NZ + 1))
    for j in range(NZ + 1):
        for i in range(NX + 1):
            var x := X0 + i * CELL
            var z := Z0 + j * CELL
            var h := raw_height(x, z)
            hts[j * s + i] = h
            verts[j * s + i] = Vector3(x, h, z)
            var t := clampf((-z - 40.0) / 260.0, 0.0, 1.0)
            var n := 0.5 + 0.5 * sin(x * 0.09) * sin(z * 0.11)
            cols[j * s + i] = Color(0.30, 0.52, 0.24).lerp(Color(0.36, 0.30, 0.20), t).darkened(0.12 * n)
    var idx := PackedInt32Array()
    idx.resize(NX * NZ * 6)
    var k := 0
    for j in range(NZ):
        for i in range(NX):
            var a := j * s + i
            var b := a + 1
            var c := a + s
            var d := c + 1
            idx[k] = a
            idx[k + 1] = b
            idx[k + 2] = c
            idx[k + 3] = b
            idx[k + 4] = d
            idx[k + 5] = c
            k += 6
    _solid(Geo.build_mesh(verts, idx, cols), Color.WHITE, "terrain", true)

# ---------------------------------------------------------------- примитивы
func _solid(mesh: Mesh, color: Color, surface: String, vcol: bool = false) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.95
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    if vcol:
        mat.vertex_color_use_as_albedo = true
    mi.material_override = mat
    add_child(mi)
    var body := StaticBody3D.new()
    body.set_meta("surface", surface)
    var cs := CollisionShape3D.new()
    var shape := mesh.create_trimesh_shape()
    shape.backface_collision = true
    cs.shape = shape
    body.add_child(cs)
    add_child(body)

func _box(c: Vector3, sz: Vector3, col: Color, surface: String, yaw: float = 0.0, vis_end: float = 0.0) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = sz
    mi.mesh = bm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = col
    mat.roughness = 0.9
    mi.material_override = mat
    mi.position = c
    mi.rotation.y = yaw
    mi.visibility_range_end = vis_end
    add_child(mi)
    var body := StaticBody3D.new()
    body.set_meta("surface", surface)
    body.position = c
    body.rotation.y = yaw
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = sz
    cs.shape = bs
    body.add_child(cs)
    add_child(body)

func _strip(pts2: Array, width: float, col: Color, surface: String, lift: float, step: float = 4.0) -> void:
    var pts: Array = []
    for p in pts2:
        pts.append(Vector3(p[0], 0.0, p[1]))
    _solid(Geo.ribbon(pts, width, Callable(self, "height_at"), lift, step), col, surface)

func _ramp(prof: Array, width: float, o: Vector3, dir: Vector3, col: Color, surface: String, lift: float = 0.0) -> void:
    _solid(Geo.extrude(prof, width, o, dir, Callable(self, "height_at"), lift), col, surface)

# ---------------------------------------------------------------- трассы
func _add_feature(f: Dictionary, trail: Array, width: float) -> void:
    var total := 0.0
    for i in range(trail.size() - 1):
        var a: Vector3 = trail[i]
        var b: Vector3 = trail[i + 1]
        total += a.distance_to(b)
    var want: float = float(f["at"]) * total
    var acc := 0.0
    var p: Vector3 = trail[0]
    var dir := Vector3(0, 0, 1)
    for i in range(trail.size() - 1):
        var a: Vector3 = trail[i]
        var b: Vector3 = trail[i + 1]
        var l := a.distance_to(b)
        if acc + l >= want:
            dir = (b - a).normalized()
            p = a.lerp(b, (want - acc) / maxf(l, 0.0001))
            break
        acc += l
    var H: float = float(f.get("H", 1.5))
    var prof: Array
    var wood := false
    match String(f["t"]):
        "kicker":
            prof = Geo.profile_kicker(float(f["L"]), H)
        "table":
            prof = Geo.profile_table(float(f["up"]), float(f["top"]), float(f["down"]), H)
        "roller":
            prof = Geo.profile_roller(float(f["L"]), H, int(f["n"]))
        _:
            prof = Geo.profile_drop(float(f["ramp"]), float(f["deck"]), H)
            wood = true
    var col := Color(0.45, 0.30, 0.18) if wood else Color(0.40, 0.29, 0.19)
    _ramp(prof, width, p, dir, col, "wood" if wood else "dirt", 0.04)

func _build_trails() -> void:
    for t in TRAILS:
        var pts: Array = []
        var pts2: Array = t["pts"]
        for p in pts2:
            pts.append(Vector3(p[0], 0.0, p[1]))
        trail_lines.append(pts)
        _strip(pts2, float(t["w"]), Color(0.42, 0.31, 0.2), "dirt", 0.05, 2.0)
        var feats: Array = t["feats"]
        for f in feats:
            _add_feature(f, pts, float(t["w"]) + 0.6)

func _dist_trail(x: float, z: float) -> float:
    var best := 1e9
    var p := Vector2(x, z)
    for line in trail_lines:
        for i in range(line.size() - 1):
            var a: Vector3 = line[i]
            var b: Vector3 = line[i + 1]
            var q := Geometry2D.get_closest_point_to_segment(p, Vector2(a.x, a.z), Vector2(b.x, b.z))
            best = minf(best, p.distance_to(q))
    return best

## Лёгкое дерево (~70 треугольников): ствол + два конуса. Цвет варьируется через цвет инстанса.
func _tree_mesh() -> ArrayMesh:
    var m := ArrayMesh.new()
    var parts := [
        [0.28, 0.38, 2.6, 6, 1.3, Color(0.35, 0.22, 0.12), true],
        [0.0, 2.1, 4.2, 8, 4.0, Color(0.12, 0.38, 0.16), false],
        [0.0, 1.5, 3.4, 8, 6.2, Color(0.15, 0.45, 0.2), false],
    ]
    for p in parts:
        var c := CylinderMesh.new()
        c.top_radius = p[0]
        c.bottom_radius = p[1]
        c.height = p[2]
        c.radial_segments = p[3]
        c.rings = 1
        c.cap_top = false
        c.cap_bottom = p[6]
        var arr := c.get_mesh_arrays()
        var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
        for i in range(v.size()):
            v[i] += Vector3(0.0, p[4], 0.0)
        arr[Mesh.ARRAY_VERTEX] = v
        m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = p[5]
        mat.vertex_color_use_as_albedo = true
        mat.roughness = 1.0
        m.surface_set_material(m.get_surface_count() - 1, mat)
    return m

func _build_trees() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    var chunk_xf := {}
    var chunk_col := {}
    var coll_pos: Array = []
    var x := -400.0
    while x < 400.0:
        var z := -770.0
        while z < -55.0:
            var px := x + rng.randf_range(-5.0, 5.0)
            var pz := z + rng.randf_range(-5.0, 5.0)
            z += 12.0
            if pz > -60.0 or sin(px * 0.021) * sin(pz * 0.027) > 0.7:
                continue                                  # поляны
            var dt := _dist_trail(px, pz)
            if dt < 6.0:
                continue                                  # трасса свободна
            var sc := rng.randf_range(0.8, 1.5)
            var pos := Vector3(px, height_at(px, pz) - 0.2, pz)
            var xf := Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(sc, sc * rng.randf_range(0.9, 1.25), sc)), pos)
            var key := Vector2i(int(floor(px / 120.0)), int(floor(pz / 120.0)))
            if not chunk_xf.has(key):
                chunk_xf[key] = []
                chunk_col[key] = []
            chunk_xf[key].append(xf)
            chunk_col[key].append(Color(rng.randf_range(0.75, 1.1), rng.randf_range(0.8, 1.1), rng.randf_range(0.7, 1.0)))
            if dt < 45.0:
                coll_pos.append(pos)
        x += 12.0
    var mesh := _tree_mesh()
    for key in chunk_xf.keys():
        var xfs: Array = chunk_xf[key]
        var cols: Array = chunk_col[key]
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.use_colors = true
        mm.mesh = mesh
        mm.instance_count = xfs.size()
        for i in range(xfs.size()):
            mm.set_instance_transform(i, xfs[i])
            mm.set_instance_color(i, cols[i])
        var mmi := MultiMeshInstance3D.new()
        mmi.multimesh = mm
        mmi.visibility_range_end = 380.0
        add_child(mmi)
    # твёрдые стволы только рядом с трассами
    var body := StaticBody3D.new()
    body.set_meta("surface", "dirt")
    var cyl := CylinderShape3D.new()
    cyl.radius = 0.4
    cyl.height = 5.0
    for p in coll_pos:
        var cs := CollisionShape3D.new()
        cs.shape = cyl
        cs.position = p + Vector3(0, 2.5, 0)
        body.add_child(cs)
    add_child(body)
    # ваш forest.glb — участки подлеска вдоль трасс (тяжёлый, поэтому редко и с дальностью)
    var bands := {}
    for line in trail_lines:
        for i in range(line.size() - 1):
            var a: Vector3 = line[i]
            var b: Vector3 = line[i + 1]
            var n := int(a.distance_to(b) / 45.0)
            for k in range(n):
                var c := a.lerp(b, float(k) / maxf(n, 1))
                var side := 1.0 if rng.randf() < 0.5 else -1.0
                var ox: float = c.x + side * rng.randf_range(10.0, 30.0)
                var oz: float = c.z + rng.randf_range(-8.0, 8.0)
                if oz > -60.0 or _dist_trail(ox, oz) < 7.0:
                    continue
                var band := int(floor(oz / 200.0))
                if not bands.has(band):
                    bands[band] = []
                bands[band].append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Vector3(ox, height_at(ox, oz) - 0.3, oz)))
    for band in bands.keys():
        ModelUtil.scatter(self, "res://models/forest.glb", bands[band], "tree", 14.0, 260.0)

# ---------------------------------------------------------------- город и скейт-парк
const ROAD_X := [0.0, -220.0, 300.0]
const ROAD_Z := [250.0, 400.0]
const CITY_CENTER := Vector2(0.0, 300.0)

func _lot_ok(x: float, z: float, w: float, d: float) -> bool:
    for rx in ROAD_X:
        if absf(x - rx) < w * 0.5 + 9.5 and z > 120.0:
            return false
    for rz in ROAD_Z:
        if absf(z - rz) < d * 0.5 + 9.5:
            return false
    if x > 55.0 and x < 225.0 and z > 280.0 and z < 385.0:
        return false
    if x > -395.0 and x < -285.0 and z > 280.0 and z < 380.0:
        return false
    if absf(x) < 75.0 and z > 255.0 and z < 335.0:
        return false
    return true

## Фасад с окнами: тайл 7×7 м (2 этажа × 2 окна), без UV — триплоскостное наложение в мировых координатах.
func _facade_material(seed_v: int, wall: Color, lit: float) -> StandardMaterial3D:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_v
    var img := Image.create(128, 128, true, Image.FORMAT_RGBA8)
    img.fill(wall)
    for fy in range(2):
        for fx in range(2):
            var on := rng.randf() < lit
            var col := Color(1.0, 0.86, 0.5) if on else Color(0.13, 0.2, 0.3)
            for y in range(fy * 64 + 14, fy * 64 + 52):
                for x in range(fx * 64 + 10, fx * 64 + 54):
                    img.set_pixel(x, y, col)
        for x in range(0, 128):
            img.set_pixel(x, fy * 64, wall.darkened(0.25))      # междуэтажный пояс
    img.generate_mipmaps()
    var mat := StandardMaterial3D.new()
    mat.albedo_texture = ImageTexture.create_from_image(img)
    mat.uv1_triplanar = true
    mat.uv1_world_triplanar = true
    mat.uv1_scale = Vector3(1.0 / 7.0, 1.0 / 7.0, 1.0 / 7.0)
    mat.roughness = 0.85
    return mat

func _vis_strip(pts2: Array, width: float, col: Color, lift: float) -> void:
    var pts: Array = []
    for p in pts2:
        pts.append(Vector3(p[0], 0.0, p[1]))
    var mi := MeshInstance3D.new()
    mi.mesh = Geo.ribbon(pts, width, Callable(self, "height_at"), lift, 8.0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = col
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mi.material_override = mat
    add_child(mi)

func _build_lamps() -> void:
    var poles: Array = []
    for r in ROADS:
        for i in range(r.size() - 1):
            var a := Vector2(r[i][0], r[i][1])
            var b := Vector2(r[i + 1][0], r[i + 1][1])
            var ln := a.distance_to(b)
            var dir := (b - a).normalized()
            var nrm := Vector2(-dir.y, dir.x)
            for k in range(int(ln / 45.0)):
                var p := a + dir * (k * 45.0 + 20.0)
                for side in [-1.0, 1.0]:
                    var q := p + nrm * 6.8 * side
                    poles.append(Transform3D(Basis.IDENTITY, Vector3(q.x, 3.5, q.y)))
    var cm := CylinderMesh.new()
    cm.top_radius = 0.07
    cm.bottom_radius = 0.12
    cm.height = 7.0
    cm.radial_segments = 5
    cm.rings = 1
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.2, 0.2, 0.22)
    cm.material = mat
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = cm
    mm.instance_count = poles.size()
    for i in range(poles.size()):
        mm.set_instance_transform(i, poles[i])
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    mmi.visibility_range_end = 300.0
    add_child(mmi)

func _build_city() -> void:
    for r in ROADS:
        _strip(r, 15.0, Color(0.55, 0.55, 0.57), "concrete", 0.02, 8.0)   # тротуар
        _strip(r, 10.0, Color(0.16, 0.16, 0.18), "asphalt", 0.04, 8.0)
        _vis_strip(r, 0.3, Color(0.92, 0.82, 0.25), 0.09)                  # осевая
    _build_lamps()
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    var groups := [[], [], [], []]
    var shapes: Array = []
    var x := -430.0
    while x <= 430.0:
        var z := 140.0
        while z <= 530.0:
            var w := rng.randf_range(15.0, 25.0)
            var d := rng.randf_range(15.0, 25.0)
            var px := x + rng.randf_range(-4.0, 4.0)
            var pz := z + rng.randf_range(-4.0, 4.0)
            z += 34.0
            if rng.randf() > 0.9 or not _lot_ok(px, pz, w, d):
                continue
            var dist := Vector2(px, pz).distance_to(CITY_CENTER)
            var h := clampf(lerpf(62.0, 10.0, dist / 480.0), 8.0, 70.0) * rng.randf_range(0.55, 1.25)
            var c := Vector3(px, h * 0.5 - 0.3, pz)
            groups[rng.randi() % 4].append(Transform3D(Basis.from_scale(Vector3(w, h, d)), c))
            shapes.append([c, Vector3(w, h, d)])
        x += 34.0
    var walls := [Color(0.78, 0.78, 0.8), Color(0.83, 0.75, 0.62), Color(0.62, 0.42, 0.36), Color(0.5, 0.56, 0.66)]
    var cube := BoxMesh.new()
    cube.size = Vector3.ONE
    for v in range(4):
        var tr: Array = groups[v]
        if tr.is_empty():
            continue
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = cube
        mm.instance_count = tr.size()
        for i in range(tr.size()):
            mm.set_instance_transform(i, tr[i])
        var mmi := MultiMeshInstance3D.new()
        mmi.multimesh = mm
        mmi.material_override = _facade_material(100 + v, walls[v], 0.25)
        mmi.visibility_range_end = 750.0
        add_child(mmi)
    var body := StaticBody3D.new()
    body.set_meta("surface", "concrete")
    for sh in shapes:
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = sh[1]
        cs.shape = bs
        cs.position = sh[0]
        body.add_child(cs)
    add_child(body)
    # ваш скайлайн-«кольцо» вдали (визуально): север, запад, восток
    var pl: Array = []
    for i in range(7):
        pl.append(Transform3D(Basis(Vector3.UP, PI), Vector3(-360.0 + i * 120.0, 0.0, 545.0)))
    ModelUtil.scatter(self, "res://models/low_poly_night_city_building_skyline.glb", pl, "width", 110.0, 900.0)
    var side: Array = []
    for i in range(4):
        side.append(Transform3D(Basis(Vector3.UP, -PI / 2.0), Vector3(465.0, 0.0, 190.0 + i * 120.0)))
        side.append(Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(-465.0, 0.0, 190.0 + i * 120.0)))
    ModelUtil.scatter(self, "res://models/low_poly_night_city_building_skyline.glb", side, "width", 110.0, 900.0)

func _build_skatepark() -> void:
    var c := SKATE
    _strip([[c.x, c.z - 26.0], [c.x, c.z + 26.0]], 64.0, Color(0.62, 0.62, 0.64), "concrete", 0.05, 6.0)
    var grey := Color(0.7, 0.7, 0.72)
    var qp := Geo.profile_quarter(2.4, 1.5)
    _ramp(qp, 10.0, Vector3(c.x - 8.0, 0, c.z - 10.0), Vector3(-1, 0, 0), grey, "concrete", 0.05)
    _ramp(qp, 10.0, Vector3(c.x + 8.0, 0, c.z - 10.0), Vector3(1, 0, 0), grey, "concrete", 0.05)
    _ramp(Geo.profile_table(4.0, 5.0, 5.0, 1.1), 6.0, Vector3(c.x - 26.0, 0, c.z + 14.0), Vector3(1, 0, 0), grey, "concrete", 0.05)
    _ramp(Geo.profile_table(4.0, 5.0, 4.0, 1.0), 6.0, Vector3(c.x + 8.0, 0, c.z + 6.0), Vector3(0, 0, 1), grey, "concrete", 0.05)
    _ramp(Geo.profile_drop(5.0, 3.0, 2.4), 5.0, Vector3(c.x + 26.0, 0, c.z - 8.0), Vector3(0, 0, -1), Color(0.5, 0.35, 0.2), "wood", 0.05)
    for k in range(6):
        var hh := 0.16 * (6 - k)
        _box(Vector3(c.x + 14.0 + k * 1.2, hh * 0.5 + 0.05, c.z + 18.0), Vector3(1.2, hh, 6.0), grey, "concrete")
    _box(Vector3(c.x - 4.0, 0.3, c.z + 18.0), Vector3(9.0, 0.5, 0.5), Color(0.85, 0.75, 0.2), "concrete")
    _box(Vector3(c.x + 20.0, 0.2, c.z - 18.0), Vector3(6.0, 0.3, 3.0), grey, "concrete")

func _build_indoor_park() -> void:
    var p := Vector3(INDOOR.x, height_at(INDOOR.x, INDOOR.z), INDOOR.z)
    # крыша вырезана при оптимизации, так что внутрь можно заезжать и сверху
    ModelUtil.place_with_collision(self, "res://models/indoor_skatepark.glb", 60.0, p, "concrete")

func build() -> void:
    _build_terrain()
    _build_city()
    _build_skatepark()
    _build_indoor_park()
    _build_trails()
    _build_trees()
