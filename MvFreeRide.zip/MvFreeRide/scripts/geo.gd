class_name Geo
## Процедурная геометрия: меши из массивов, профили трамплинов, ленты дорог.
## Порядок вершин — по часовой стрелке при взгляде сверху (лицевая сторона Godot).

static func build_mesh(verts: PackedVector3Array, idx: PackedInt32Array, colors: PackedColorArray = PackedColorArray(), given: PackedVector3Array = PackedVector3Array()) -> ArrayMesh:
    var normals := PackedVector3Array()
    normals.resize(verts.size())
    var have := given.size() == verts.size()
    if have:
        normals = given
    for i in range(0 if not have else idx.size(), idx.size(), 3):
        var a: Vector3 = verts[idx[i]]
        var b: Vector3 = verts[idx[i + 1]]
        var c: Vector3 = verts[idx[i + 2]]
        var n: Vector3 = (c - a).cross(b - a)
        normals[idx[i]] += n
        normals[idx[i + 1]] += n
        normals[idx[i + 2]] += n
    if not have:
        for i in range(normals.size()):
            var nn: Vector3 = normals[i]
            normals[i] = nn.normalized() if nn.length() > 0.00001 else Vector3.UP
    var arr := []
    arr.resize(Mesh.ARRAY_MAX)
    arr[Mesh.ARRAY_VERTEX] = verts
    arr[Mesh.ARRAY_NORMAL] = normals
    arr[Mesh.ARRAY_INDEX] = idx
    if colors.size() == verts.size():
        arr[Mesh.ARRAY_COLOR] = colors
    var m := ArrayMesh.new()
    m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
    return m

# ---------- Профили: Vector2(расстояние вдоль, высота над землёй) ----------
static func profile_kicker(L: float, H: float) -> Array:
    var p := []
    var n := 10
    for i in range(n + 1):
        var t: float = float(i) / n
        p.append(Vector2(L * t, H * pow(t, 1.8)))
    p.append(Vector2(L + 0.01, 0.0))
    return p

static func profile_table(up: float, top: float, down: float, H: float) -> Array:
    var p := profile_kicker(up, H)
    p.pop_back()
    p.append(Vector2(up + top, H))
    p.append(Vector2(up + top + down, 0.0))
    return p

static func profile_roller(L: float, H: float, count: int) -> Array:
    var p := []
    var n := 12 * count
    for i in range(n + 1):
        var t: float = float(i) / n
        p.append(Vector2(L * t, H * 0.5 * (1.0 - cos(TAU * count * t))))
    return p

static func profile_drop(ramp: float, deck: float, H: float) -> Array:
    return [Vector2(0, 0), Vector2(ramp, H), Vector2(ramp + deck, H), Vector2(ramp + deck + 0.01, 0)]

static func profile_quarter(R: float, deck: float) -> Array:
    var p := []
    var n := 12
    for i in range(n + 1):
        var s: float = R * float(i) / n
        p.append(Vector2(s, R - sqrt(maxf(0.0, R * R - s * s))))
    p.append(Vector2(R + deck, R))
    p.append(Vector2(R + deck + 0.01, 0.0))
    return p

static func sample(p: Array, s: float) -> float:
    var first: Vector2 = p[0]
    var last: Vector2 = p[p.size() - 1]
    if s <= first.x:
        return first.y
    if s >= last.x:
        return last.y
    for i in range(1, p.size()):
        var cur: Vector2 = p[i]
        if s <= cur.x:
            var prev: Vector2 = p[i - 1]
            var t: float = (s - prev.x) / maxf(0.00001, cur.x - prev.x)
            return lerpf(prev.y, cur.y, t)
    return 0.0

## Экструзия профиля вдоль направления; вершины ложатся на рельеф (hf(x,z) -> высота) + высота профиля.
static func extrude(prof: Array, width: float, o: Vector3, d_in: Vector3, hf: Callable, lift: float = 0.0, step: float = 0.5) -> ArrayMesh:
    var d := Vector3(d_in.x, 0.0, d_in.z).normalized()
    var r := Vector3(-d.z, 0.0, d.x)
    var last: Vector2 = prof[prof.size() - 1]
    var L: float = last.x
    var n := maxi(2, int(ceil(L / step)))
    var wn := 4
    var verts := PackedVector3Array()
    for i in range(n + 1):
        var s: float = L * float(i) / n
        var h: float = sample(prof, s)
        for j in range(wn + 1):
            var u: float = (float(j) / wn - 0.5) * width
            var p: Vector3 = o + d * s + r * u
            var edge: float = 1.0 - pow(absf(2.0 * float(j) / wn - 1.0), 4.0) * 0.15
            p.y = float(hf.call(p.x, p.z)) + lift + h * edge
            verts.append(p)
    var idx := PackedInt32Array()
    for i in range(n):
        for j in range(wn):
            var a: int = i * (wn + 1) + j
            var b: int = a + 1
            var c: int = a + (wn + 1)
            var e: int = c + 1
            idx.append_array(PackedInt32Array([a, c, b, b, c, e]))
    return build_mesh(verts, idx)

## Лента (дорога/трейл) по полилинии Vector3, прилегает к рельефу.
static func ribbon(pts: Array, width: float, hf: Callable, lift: float = 0.03, step: float = 3.0) -> ArrayMesh:
    var s: Array = []
    for i in range(pts.size() - 1):
        var a: Vector3 = pts[i]
        var b: Vector3 = pts[i + 1]
        var k := maxi(1, int(a.distance_to(b) / step))
        for t in range(k):
            s.append(a.lerp(b, float(t) / k))
    s.append(pts[pts.size() - 1])
    var verts := PackedVector3Array()
    for i in range(s.size()):
        var p: Vector3 = s[i]
        var d: Vector3 = (s[i + 1] - p) if i + 1 < s.size() else (p - s[i - 1])
        d.y = 0.0
        d = d.normalized()
        var r := Vector3(-d.z, 0.0, d.x)
        for sg in [-1.0, 1.0]:
            var q: Vector3 = p + r * (0.5 * width * sg)
            q.y = float(hf.call(q.x, q.z)) + lift
            verts.append(q)
    var idx := PackedInt32Array()
    for i in range(s.size() - 1):
        var a2: int = i * 2
        idx.append_array(PackedInt32Array([a2, a2 + 2, a2 + 1, a2 + 1, a2 + 2, a2 + 3]))
    return build_mesh(verts, idx)
