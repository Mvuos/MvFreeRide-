class_name ModelUtil

static var _vis_cache := {}
## Загрузка .glb во время игры, авто-подгонка масштаба/ориентации, MultiMesh-расстановка.

static func load_scene(path: String) -> Node3D:
    if not ResourceLoader.exists(path):
        return null
    var ps = load(path)
    if ps == null or not (ps is PackedScene):
        return null
    var n = ps.instantiate()
    return n as Node3D

static func rel_xf(n: Node) -> Transform3D:
    var xf := Transform3D.IDENTITY
    var cur: Node = n
    while cur != null:
        if cur is Node3D:
            xf = (cur as Node3D).transform * xf
        cur = cur.get_parent()
    return xf

static func collect(n: Node, out: Array) -> void:
    if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
        out.append(n)
    for c in n.get_children():
        collect(c, out)

static func bounds(root: Node, pre: Transform3D = Transform3D.IDENTITY) -> AABB:
    var meshes: Array = []
    collect(root, meshes)
    var bb := AABB()
    var first := true
    for mi in meshes:
        var m: MeshInstance3D = mi
        var xf: Transform3D = pre * rel_xf(m)
        var a: AABB = xf * m.mesh.get_aabb()
        if first:
            bb = a
            first = false
        else:
            bb = bb.merge(a)
    return bb

static func find_by_name(n: Node, sub: String) -> Node3D:
    if n is Node3D and String(n.name).to_lower().contains(sub):
        return n as Node3D
    for c in n.get_children():
        var r := find_by_name(c, sub)
        if r != null:
            return r
    return null

## Обёртка: поворот phi вокруг Y, масштаб s, центр по XZ в 0, низ на Y=0.
static func fit_wrapper(root: Node3D, phi: float, s: float) -> Node3D:
    var pre := Transform3D(Basis(Vector3.UP, phi), Vector3.ZERO)
    var bb := bounds(root, pre)
    var w := Node3D.new()
    var b := Basis(Vector3.UP, phi).scaled(Vector3(s, s, s))
    var off := Vector3(-(bb.position.x + bb.size.x * 0.5) * s, -bb.position.y * s, -(bb.position.z + bb.size.z * 0.5) * s)
    w.transform = Transform3D(b, off)
    w.add_child(root)
    return w

## После упрощения сетки возможны перевёрнутые треугольники — рисуем обе стороны.
static func _two_sided(root: Node) -> void:
    var meshes: Array = []
    collect(root, meshes)
    for mi in meshes:
        var m: MeshInstance3D = mi
        for i in range(m.mesh.get_surface_count()):
            var mat = m.mesh.surface_get_material(i)
            if mat is BaseMaterial3D:
                (mat as BaseMaterial3D).cull_mode = BaseMaterial3D.CULL_DISABLED

## Статичная модель с коллизией (скейт-парк): масштаб по большей стороне footprint, низ на pos.y.
static func place_with_collision(parent: Node3D, path: String, footprint: float, pos: Vector3, surface: String) -> bool:
    var root := load_scene(path)
    if root == null:
        return false
    var bb := bounds(root)
    var s: float = footprint / maxf(maxf(bb.size.x, bb.size.z), 0.001)
    var fit := fit_wrapper(root, 0.0, s)
    fit.position = pos
    parent.add_child(fit)
    var meshes: Array = []
    collect(fit, meshes)
    for mi in meshes:
        var m: MeshInstance3D = mi
        m.visibility_range_end = 600.0
        var body := StaticBody3D.new()
        body.set_meta("surface", surface)
        var cs := CollisionShape3D.new()
        var shape := m.mesh.create_trimesh_shape()
        shape.backface_collision = true
        cs.shape = shape
        body.add_child(cs)
        m.add_child(body)
    return true

## Техника: длинная ось -> Z, перед -> -Z (по положению переднего/заднего колеса, если узлы найдены).
static func make_vehicle_visual(path: String, length: float) -> Node3D:
    if _vis_cache.has(path):
        return (_vis_cache[path] as Node3D).duplicate()
    var root := load_scene(path)
    if root == null:
        return null
    var bb := bounds(root)
    var d := Vector3(1, 0, 0) if bb.size.x > bb.size.z else Vector3(0, 0, 1)
    var wf := find_by_name(root, "wheel_f")
    if wf == null:
        wf = find_by_name(root, "front_wheel")
    var wr := find_by_name(root, "wheel_b")
    if wr == null:
        wr = find_by_name(root, "rear_wheel")
    if wf != null and wr != null:
        var a := bounds(wf)
        var b := bounds(wr)
        var dir: Vector3 = (a.position + a.size * 0.5) - (b.position + b.size * 0.5)
        dir.y = 0.0
        if dir.length() > 0.01:
            d = dir.normalized()
    var phi := atan2(d.x, -d.z)
    var pre := Transform3D(Basis(Vector3.UP, phi), Vector3.ZERO)
    var bb2 := bounds(root, pre)
    var s: float = length / maxf(bb2.size.z, 0.001)
    _two_sided(root)
    var wrapped := fit_wrapper(root, phi, s)
    _vis_cache[path] = wrapped
    return wrapped.duplicate()

## Мелкий реквизит (шлем): масштаб по максимальному размеру.
static func make_prop(path: String, max_extent: float) -> Node3D:
    var root := load_scene(path)
    if root == null:
        return null
    var bb := bounds(root)
    var m: float = maxf(bb.size.x, maxf(bb.size.y, bb.size.z))
    return fit_wrapper(root, 0.0, max_extent / maxf(m, 0.001))

## Расстановка множества копий через MultiMesh (1 draw call на подмеш).
## Возвращает размер модели после масштабирования (Vector3.ZERO при неудаче).
static func scatter(parent: Node3D, path: String, placements: Array, mode: String, target: float, vis_end: float = 420.0) -> Vector3:
    var root := load_scene(path)
    if root == null or placements.is_empty():
        return Vector3.ZERO
    var bb := bounds(root)
    var horiz: float = maxf(bb.size.x, bb.size.z)
    var s: float = target / maxf(horiz, 0.001)
    var fit := fit_wrapper(root, 0.0, s)
    var meshes: Array = []
    collect(fit, meshes)
    for mi in meshes:
        var m: MeshInstance3D = mi
        var rel: Transform3D = rel_xf(m)
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = m.mesh
        mm.instance_count = placements.size()
        for i in range(placements.size()):
            var pl: Transform3D = placements[i]
            mm.set_instance_transform(i, pl * rel)
        var mmi := MultiMeshInstance3D.new()
        mmi.multimesh = mm
        mmi.visibility_range_end = vis_end
        parent.add_child(mmi)
    var sz: Vector3 = bb.size * s
    fit.free()
    return sz
