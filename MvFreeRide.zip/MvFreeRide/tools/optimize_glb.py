#!/usr/bin/env python3
"""Оптимизатор .glb для мобильных: упрощение сеток + сжатие текстур. Нужны: numpy, Pillow.

  python tools/optimize_glb.py in.glb out.glb --tris 30000 --tex 512 [--drop roof,ceil]

* Упрощение: кластеризация вершин по сетке с квадриками ошибки (QEM) — тонкие трубки рамы сохраняются,
  размер ячейки подбирается бинарным поиском под бюджет треугольников (делится между мешами пропорционально).
* Текстуры: уменьшаются до --tex px по большей стороне; непрозрачные -> JPEG, с альфой -> PNG.
* Убирает TANGENT и неиспользуемые наборы UV (Godot сам посчитает тангенты)."""
import argparse, io, json, struct
import numpy as np
from PIL import Image

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

def read_glb(path):
    d = open(path, "rb").read()
    jl, _ = struct.unpack("<II", d[12:20])
    j = json.loads(d[20:20 + jl])
    off = 20 + jl
    bl, _ = struct.unpack("<II", d[off:off + 8])
    return j, d[off + 8:off + 8 + bl]

def acc(j, b, i):
    a = j["accessors"][i]
    bv = j["bufferViews"][a["bufferView"]]
    dt = np.dtype(CT[a["componentType"]]); nc = NC[a["type"]]
    stride = bv.get("byteStride") or dt.itemsize * nc
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    arr = np.ndarray((a["count"], nc), dt, b, base, (stride, dt.itemsize)).copy()
    if a.get("normalized"):
        arr = arr.astype(np.float32) / (np.iinfo(dt).max if dt.kind == "u" else np.iinfo(dt).max)
    return arr[:, 0] if nc == 1 else arr

def decimate(P, N, F, extra, target, uv_key):
    """P (n,3) float64, F (m,3). extra: dict имя->(n,k) массивы. Возвращает новые P,N,F,extra."""
    n, m = len(P), len(F)
    a, b, c = P[F[:, 0]], P[F[:, 1]], P[F[:, 2]]
    fn = np.cross(b - a, c - a)
    area = np.linalg.norm(fn, axis=1) * 0.5
    nf = fn / np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-20)
    d = -(nf * a).sum(1)
    pl = np.concatenate([nf, d[:, None]], 1)
    iu = [(0, 0), (0, 1), (0, 2), (0, 3), (1, 1), (1, 2), (1, 3), (2, 2), (2, 3), (3, 3)]
    Qf = np.stack([pl[:, i] * pl[:, j] * area for i, j in iu], 1)
    Qv = np.zeros((n, 10))
    for k in range(10):
        for t in range(3):
            Qv[:, k] += np.bincount(F[:, t], weights=Qf[:, k], minlength=n)
    mn = P.min(0); diag = float(np.linalg.norm(P.max(0) - mn)) or 1.0
    cell0 = np.floor((P - mn) / (diag / 4096)).astype(np.int64)  # только для типа

    def cluster(h):
        cell = np.floor((P - mn) / h).astype(np.int64)
        key = (cell[:, 0] * 4097 + cell[:, 1]) * 4097 + cell[:, 2]
        if uv_key is not None:
            key = key * 4096 + uv_key
        _, inv = np.unique(key, return_inverse=True)
        return inv.reshape(-1)

    def count(h):
        inv = cluster(h); Fc = inv[F]
        ok = (Fc[:, 0] != Fc[:, 1]) & (Fc[:, 1] != Fc[:, 2]) & (Fc[:, 0] != Fc[:, 2])
        return int(ok.sum())

    lo, hi = diag / 4000.0, diag / 2.0
    for _ in range(18):
        mid = (lo * hi) ** 0.5
        if count(mid) > target: lo = mid
        else: hi = mid
    h = hi
    inv = cluster(h); k = int(inv.max()) + 1
    cnt = np.bincount(inv, minlength=k).astype(np.float64)
    cen = np.stack([np.bincount(inv, weights=P[:, i], minlength=k) for i in range(3)], 1) / cnt[:, None]
    Q = np.stack([np.bincount(inv, weights=Qv[:, i], minlength=k) for i in range(10)], 1)
    A = np.zeros((k, 3, 3))
    A[:, 0, 0], A[:, 0, 1], A[:, 0, 2] = Q[:, 0], Q[:, 1], Q[:, 2]
    A[:, 1, 0], A[:, 1, 1], A[:, 1, 2] = Q[:, 1], Q[:, 4], Q[:, 5]
    A[:, 2, 0], A[:, 2, 1], A[:, 2, 2] = Q[:, 2], Q[:, 5], Q[:, 7]
    bb = np.stack([Q[:, 3], Q[:, 6], Q[:, 8]], 1)
    mu = 8e-2 * (np.trace(A, axis1=1, axis2=2) / 3.0) + 1e-12
    A += mu[:, None, None] * np.eye(3)
    x = np.linalg.solve(A, (-bb + mu[:, None] * cen)[:, :, None])[:, :, 0]
    bad = (np.abs(x - cen).max(1) > 0.5 * h) | ~np.isfinite(x).all(1)
    x[bad] = cen[bad]
    Fc = inv[F]
    ok = (Fc[:, 0] != Fc[:, 1]) & (Fc[:, 1] != Fc[:, 2]) & (Fc[:, 0] != Fc[:, 2])
    Fc = Fc[ok]
    Fc = Fc[np.unique(np.sort(Fc, 1), axis=0, return_index=True)[1]]
    used = np.unique(Fc)
    remap = np.full(k, -1, np.int64); remap[used] = np.arange(len(used))
    Fo = remap[Fc]
    nn = np.stack([np.bincount(inv, weights=N[:, i], minlength=k) for i in range(3)], 1) if N is not None else None
    if nn is not None:
        nn = nn / np.maximum(np.linalg.norm(nn, axis=1, keepdims=True), 1e-12)
        nn = nn[used]
    # атрибуты (UV/цвет) — от вершины, ближайшей к новой позиции кластера
    dist = ((P - x[inv]) ** 2).sum(1)
    order = np.lexsort((dist, inv))
    first = order[np.searchsorted(inv[order], np.arange(k))]
    ex = {nm: arr[first][used] for nm, arr in extra.items()}
    return x[used], nn, Fo, ex

def convert_image(data, cap):
    im = Image.open(io.BytesIO(data)); im.load()
    if max(im.size) > cap:
        s = cap / max(im.size)
        im = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.LANCZOS)
    has_alpha = im.mode in ("RGBA", "LA", "P") and "A" in im.convert("RGBA").getbands() and np.asarray(im.convert("RGBA"))[..., 3].min() < 250
    out = io.BytesIO()
    if has_alpha:
        im.convert("RGBA").save(out, "PNG", optimize=True); return out.getvalue(), "image/png"
    im.convert("RGB").save(out, "JPEG", quality=85, optimize=True); return out.getvalue(), "image/jpeg"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("dst")
    ap.add_argument("--tris", type=int, default=30000); ap.add_argument("--tex", type=int, default=512)
    ap.add_argument("--uvsplit", action="store_true", help="не склеивать вершины из разных областей UV (больше полигонов)")
    ap.add_argument("--drop", default="", help="имена узлов (подстроки через запятую), которые удалить")
    a = ap.parse_args()
    j, b = read_glb(a.src)
    drops = [s for s in a.drop.lower().split(",") if s]
    for n in j["nodes"]:
        if "mesh" in n and any(s in (n.get("name") or "").lower() for s in drops):
            del n["mesh"]
    inst = {}
    for n in j["nodes"]:
        if "mesh" in n: inst[n["mesh"]] = inst.get(n["mesh"], 0) + 1
    used_mesh = sorted(inst)
    tc_used = {0}
    for mt in j.get("materials", []):
        for t in [mt.get("pbrMetallicRoughness", {}).get("baseColorTexture"), mt.get("pbrMetallicRoughness", {}).get("metallicRoughnessTexture"),
                  mt.get("normalTexture"), mt.get("occlusionTexture"), mt.get("emissiveTexture")]:
            if t: tc_used.add(t.get("texCoord", 0))
    prims = {}
    total = 0
    raw_total = 0
    for mi in used_mesh:
        for pi, p in enumerate(j["meshes"][mi]["primitives"]):
            ic = j["accessors"][p["indices"]]["count"] // 3 if "indices" in p else j["accessors"][p["attributes"]["POSITION"]]["count"] // 3
            prims[(mi, pi)] = ic; total += ic * inst[mi]; raw_total += ic
    print(f"{a.src}: {total} tris (с инстансами) -> бюджет {a.tris}")
    out = bytearray(); bvs = []; accs = []
    def add_view(data, target=None):
        while len(out) % 4: out.append(0)
        bvs.append({"buffer": 0, "byteOffset": len(out), "byteLength": len(data), **({"target": target} if target else {})})
        out.extend(data); return len(bvs) - 1
    def add_acc(arr, ctype, typ, target, minmax=False):
        v = add_view(arr.tobytes(), target)
        d = {"bufferView": v, "componentType": ctype, "count": int(len(arr)), "type": typ}
        if minmax: d["min"] = [float(x) for x in arr.min(0)]; d["max"] = [float(x) for x in arr.max(0)]
        accs.append(d); return len(accs) - 1
    new_meshes = []; mesh_map = {}
    for mi in used_mesh:
        newp = []
        for pi, p in enumerate(j["meshes"][mi]["primitives"]):
            if p.get("mode", 4) != 4: continue
            at = p["attributes"]
            P = acc(j, b, at["POSITION"]).astype(np.float64)
            N = acc(j, b, at["NORMAL"]).astype(np.float64) if "NORMAL" in at else None
            F = (acc(j, b, p["indices"]).astype(np.int64).reshape(-1, 3) if "indices" in p else np.arange(len(P)).reshape(-1, 3))
            extra = {}
            for kname in at:
                if kname.startswith("TEXCOORD_") and int(kname[9:]) in tc_used: extra[kname] = acc(j, b, at[kname]).astype(np.float32)
                elif kname.startswith("COLOR_0"): extra[kname] = acc(j, b, at[kname]).astype(np.float32)
            target = max(40, int(a.tris * prims[(mi, pi)] / max(total, 1)))
            if raw_total > a.tris and len(F) > target and len(F) > 300:  # уже в бюджете -> геометрию не трогаем
                uvk = None
                if a.uvsplit and "TEXCOORD_0" in extra and j.get("images"):
                    uv = extra["TEXCOORD_0"]; uvk = (np.floor((uv[:, 0] % 1.0) * 8).astype(np.int64) * 8 + np.floor((uv[:, 1] % 1.0) * 8).astype(np.int64))
                P, N, F, extra = decimate(P, N, F, extra, target, uvk)
            attrs = {"POSITION": add_acc(P.astype(np.float32), 5126, "VEC3", 34962, True)}
            if N is not None: attrs["NORMAL"] = add_acc(N.astype(np.float32), 5126, "VEC3", 34962)
            for kname, arr in extra.items(): attrs[kname] = add_acc(arr.astype(np.float32), 5126, "VEC2" if arr.shape[1] == 2 else "VEC%d" % arr.shape[1], 34962)
            Fi = F.astype(np.uint16 if len(P) < 65535 else np.uint32).reshape(-1)
            np_ = {"attributes": attrs, "indices": add_acc(Fi, 5123 if Fi.dtype == np.uint16 else 5125, "SCALAR", 34963)}
            if "material" in p: np_["material"] = p["material"]
            newp.append(np_)
        mesh_map[mi] = len(new_meshes); new_meshes.append({"name": j["meshes"][mi].get("name", ""), "primitives": newp})
    for n in j["nodes"]:
        if "mesh" in n: n["mesh"] = mesh_map[n["mesh"]]
    imgs = []
    for im in j.get("images", []):
        bv = j["bufferViews"][im["bufferView"]]
        data = b[bv.get("byteOffset", 0):bv.get("byteOffset", 0) + bv["byteLength"]]
        nd, mime = convert_image(data, a.tex)
        imgs.append({"bufferView": add_view(nd), "mimeType": mime, **({"name": im["name"]} if "name" in im else {})})
    j["meshes"] = new_meshes; j["accessors"] = accs; j["bufferViews"] = bvs
    j["buffers"] = [{"byteLength": len(out)}]
    if imgs: j["images"] = imgs
    js = json.dumps(j, separators=(",", ":")).encode()
    js += b" " * ((4 - len(js) % 4) % 4)
    out += b"\0" * ((4 - len(out) % 4) % 4)
    glb = struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(js) + 8 + len(out)) + struct.pack("<I4s", len(js), b"JSON") + js + struct.pack("<I4s", len(out), b"BIN\0") + bytes(out)
    open(a.dst, "wb").write(glb)
    nt = sum(len(m_["primitives"]) and sum(accs[p_["indices"]]["count"] for p_ in m_["primitives"]) // 3 * inst[k] for k, m_ in zip(used_mesh, new_meshes))
    print(f"-> {a.dst}: {nt} tris, {len(glb)/1e6:.2f} MB")

if __name__ == "__main__":
    main()
