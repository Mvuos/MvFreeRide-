#!/usr/bin/env python3
"""Вырезает одно «типичное» дерево из модели-макета леса (forest.glb): ищет связные компоненты геометрии.
  python tools/extract_tree.py forest.glb tree_raw.glb   (затем optimize_glb.py для сжатия текстур)"""
import sys, os, json, struct, numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
sys.path.insert(0, os.path.dirname(__file__)); import optimize_glb as o

src, dst = sys.argv[1], sys.argv[2]
j, b = o.read_glb(src)
comps = []
data = {}
for mi, m in enumerate(j["meshes"]):
    for pi, p in enumerate(m["primitives"]):
        at = p["attributes"]
        P = o.acc(j, b, at["POSITION"]).astype(np.float64); F = o.acc(j, b, p["indices"]).astype(np.int64).reshape(-1, 3)
        N = o.acc(j, b, at["NORMAL"]).astype(np.float32) if "NORMAL" in at else None
        UV = o.acc(j, b, at["TEXCOORD_0"]).astype(np.float32) if "TEXCOORD_0" in at else None
        _, w = np.unique(np.round(P / 1e-3).astype(np.int64), axis=0, return_inverse=True); w = w.reshape(-1)
        n = w.max() + 1
        g = coo_matrix((np.ones(len(F) * 2), (np.r_[w[F[:, 0]], w[F[:, 1]]], np.r_[w[F[:, 1]], w[F[:, 2]]])), shape=(n, n))
        _, lab = connected_components(g, directed=False)
        tl = lab[w[F[:, 0]]]
        data[(mi, pi)] = (P, N, UV, F, p.get("material"), tl)
        for l in np.unique(tl):
            t = np.nonzero(tl == l)[0]; pts = P[F[t]].reshape(-1, 3)
            comps.append({"key": (mi, pi), "tris": t, "mn": pts.min(0), "mx": pts.max(0)})
H = np.array([c["mx"][1] - c["mn"][1] for c in comps]); T = np.array([len(c["tris"]) for c in comps])
cand = [i for i in range(len(comps)) if H[i] > 1.2 and T[i] > 100]
print("компонент:", len(comps), "кандидатов в деревья:", len(cand))
cand.sort(key=lambda i: H[i]); pick = comps[cand[int(len(cand) * 0.7)]]
cx, cz = (pick["mn"][0] + pick["mx"][0]) / 2, (pick["mn"][2] + pick["mx"][2]) / 2; y0 = pick["mn"][1]
sel = {}
for c in comps:
    ccx, ccz = (c["mn"][0] + c["mx"][0]) / 2, (c["mn"][2] + c["mx"][2]) / 2
    if abs(ccx - cx) < 0.7 and abs(ccz - cz) < 0.7 and c["mn"][1] < y0 + 0.4 and (c["mx"][1] - c["mn"][1]) < 4.0:
        sel.setdefault(c["key"], []).append(c["tris"])
out = bytearray(); bvs = []; accs = []; prims = []
def view(raw, tgt=None):
    while len(out) % 4: out.append(0)
    bvs.append({"buffer": 0, "byteOffset": len(out), "byteLength": len(raw), **({"target": tgt} if tgt else {})}); out.extend(raw); return len(bvs) - 1
def accessor(a, ct, ty, tgt, mm=False):
    d = {"bufferView": view(a.tobytes(), tgt), "componentType": ct, "count": int(len(a)), "type": ty}
    if mm: d["min"] = [float(x) for x in a.min(0)]; d["max"] = [float(x) for x in a.max(0)]
    accs.append(d); return len(accs) - 1
total = 0
for key, lst in sel.items():
    P, N, UV, F, mat, _ = data[key]; t = np.concatenate(lst); Fs = F[t]
    used, inv = np.unique(Fs, return_inverse=True); Fn = inv.reshape(-1, 3)
    Pn = (P[used] - np.array([cx, y0, cz])).astype(np.float32)
    at = {"POSITION": accessor(Pn, 5126, "VEC3", 34962, True)}
    if N is not None: at["NORMAL"] = accessor(N[used], 5126, "VEC3", 34962)
    if UV is not None: at["TEXCOORD_0"] = accessor(UV[used], 5126, "VEC2", 34962)
    pr = {"attributes": at, "indices": accessor(Fn.astype(np.uint32).reshape(-1), 5125, "SCALAR", 34963)}
    if mat is not None: pr["material"] = mat
    prims.append(pr); total += len(Fn)
imgs = []
for im in j.get("images", []):
    bv = j["bufferViews"][im["bufferView"]]
    imgs.append({"bufferView": view(b[bv.get("byteOffset", 0):bv.get("byteOffset", 0) + bv["byteLength"]]), "mimeType": im.get("mimeType", "image/png")})
J = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": [0]}], "nodes": [{"mesh": 0, "name": "tree"}],
     "meshes": [{"primitives": prims}], "accessors": accs, "bufferViews": bvs, "buffers": [{"byteLength": len(out)}]}
for k in ("materials", "textures", "samplers"):
    if k in j: J[k] = j[k]
if imgs: J["images"] = imgs
js = json.dumps(J, separators=(",", ":")).encode(); js += b" " * ((4 - len(js) % 4) % 4); out += b"\0" * ((4 - len(out) % 4) % 4)
open(dst, "wb").write(struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(js) + 8 + len(out)) + struct.pack("<I4s", len(js), b"JSON") + js + struct.pack("<I4s", len(out), b"BIN\0") + bytes(out))
print("дерево:", total, "треугольников, высота %.2f м, примитивов %d" % (pick["mx"][1] - pick["mn"][1], len(prims)))
