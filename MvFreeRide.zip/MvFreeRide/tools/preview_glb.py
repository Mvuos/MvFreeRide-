#!/usr/bin/env python3
"""Силуэт-превью .glb (боковой вид) для сравнения оригинала и оптимизированной модели.
  python tools/preview_glb.py orig.glb opt.glb out.png"""
import sys, numpy as np, cv2, os
sys.path.insert(0, os.path.dirname(__file__)); import optimize_glb as o

def node_mat(n):
    if "matrix" in n: return np.array(n["matrix"]).reshape(4, 4).T
    x, y, z, w = n.get("rotation", [0, 0, 0, 1])
    R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
    t = np.eye(4); t[:3, :3] = R @ np.diag(n.get("scale", [1, 1, 1])); t[:3, 3] = n.get("translation", [0, 0, 0]); return t

def tris(path):
    j, b = o.read_glb(path); out = []
    def walk(i, M):
        n = j["nodes"][i]; M = M @ node_mat(n)
        if "mesh" in n:
            for p in j["meshes"][n["mesh"]]["primitives"]:
                P = o.acc(j, b, p["attributes"]["POSITION"]).astype(float); F = o.acc(j, b, p["indices"]).astype(int).reshape(-1, 3)
                out.append(((M[:3, :3] @ P.T).T + M[:3, 3])[F])
        for c in n.get("children", []): walk(c, M)
    for r in j["scenes"][j.get("scene", 0)]["nodes"]: walk(r, np.eye(4))
    return np.concatenate(out)

def render(T, ax, size=500):
    a, bx = ax; pts = T.reshape(-1, 3); mn, mx = pts.min(0), pts.max(0); sc = (size - 20) / max((mx - mn)[[a, bx]])
    img = np.full((size, size), 255, np.uint8)
    n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    order = np.argsort(T.mean(1)[:, 3 - a - bx]); sh = (np.abs(n @ np.array([.4, .7, .5]) / 0.95) * 160 + 60).astype(int)
    for i in order:
        p = (T[i][:, [a, bx]] - mn[[a, bx]]) * sc + 10; p[:, 1] = size - p[:, 1]
        cv2.fillConvexPoly(img, p.astype(np.int32), int(sh[i]))
    return img

if __name__ == "__main__":
    A, B = tris(sys.argv[1]), tris(sys.argv[2]); ext = A.reshape(-1, 3).max(0) - A.reshape(-1, 3).min(0)
    ax = [int(i) for i in np.argsort(ext)[::-1][:2]]
    cv2.imwrite(sys.argv[3], np.hstack([render(A, ax), render(B, ax)]))
